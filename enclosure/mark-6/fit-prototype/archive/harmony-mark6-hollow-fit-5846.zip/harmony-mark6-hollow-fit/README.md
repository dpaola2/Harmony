# Mark 6 hollow fit prototype

Prepared September 22, 2026 after Dave accepted the 74 × 178 × 28 mm solid size dummy. This is an unpowered fit shell for the current carrier geometry. The display mount remains provisional because the selected Adafruit #5846 is discontinued at DigiKey and has no verified stock source. See the [sourcing record](../../../hardware/mark-6/carrier-rev-a/display-sourcing.md).

## Print files

Print one [tray](print/harmony-mark6-tray.3mf) and one [front](print/harmony-mark6-front.3mf). Both files already lie flat on the bed: tray floor down, front outside face down. Use 100% scale, millimetres. The 3MF files contain geometry only, with no printer profile or toolpaths.

Start with PLA, a 0.4 mm nozzle and 0.2 mm layers. The nominal 1.6 mm walls suit four 0.4 mm extrusion widths. Inspect the sliced preview, especially the two-layer display bezel and the short roof above the card opening. No supports are intended, but the card opening requires a roughly 20 mm bridge. Use the printer's normal PLA bridge settings; slicer and print results have not been verified.

The optional [carrier gauge](print/harmony-mark6-carrier-gauge.3mf) reproduces the board outline and eight mounting holes. It has no contacts. Print four copies of the [12 mm ANO spacer](print/harmony-mark6-ano-spacer-12mm.3mf) when checking the controls stack. STL equivalents are in `print/`; editable STEP exports are in `cad/`.

## What to check

1. Dry-fit the empty tray and front. The alignment lip has 0.25 mm radial clearance. It is not a snap latch; use tape for the trial.
2. Set the carrier gauge on the four posts. Carrier bottom is 6.5 mm above the outside rear face. The 2.1 mm blind pilot holes are a starting point for M2.5 screws cutting threads in plastic; establish fit gently before tightening. Choose screw length from the actual stack, without bottoming in the roughly 5.5 mm pilot depth.
3. Check the Feather with its actual factory headers and Samtec sockets once available. The model assumes a 2.54 mm male-header body, giving only 0.88 mm nominal clearance below the front. The gauge cannot validate electrical mating or header insertion depth.
4. Check the ANO board on 12 mm spacers. The wheel opening is 35.4 mm. Its rotation, click travel and cable exit need a physical check. The firmware initially reports raw inputs; button direction labels must be checked against this rotated mounting.
5. Check USB plug reach and microSD removal through the generous side openings. Keep USB unplugged from power during this mechanical trial. The plug needs room outside the Feather connector, which is recessed from the case edge.
6. Trial the display and ribbon only once the exact module is settled. The current recess assumes a 66.04 × 96.52 × 8 mm module. Its 0.4 mm bezel is a sacrificial fit feature, with no permanent display fasteners. Support the display by hand and do not force the front closed.

The battery reservation remains empty and unconnected. The shell does not establish battery retention, thermal clearance or swelling allowance. There are no validated final enclosure fasteners or display retainers yet.

## Validation

`validation.json` records one valid solid per part, watertight meshes, consistent winding, flat bed placement, 3MF round-trip dimensions and file hashes. All four part types fit within a 256 mm square bed. Nominal tray/front intersections with the vendor Feather and ANO solids, assumed display envelope and reserved battery volume are zero. This checks the modeled geometry; it does not establish tolerances or physical fit.

Rebuild with:

```sh
uv run --with cadquery==2.8.0 --with trimesh --with matplotlib --with networkx --with lxml python build.py
uv run --with cadquery==2.8.0 --with trimesh --with matplotlib --with networkx --with lxml python render_preview.py
```

The [preview](preview/hollow-fit.png) is rendered from the delivered STL meshes. Related work: HARMONY-17 and the [carrier mechanical review](../../../hardware/mark-6/carrier-rev-a/mechanical-review.md).
