# Harmony R1 review package

Start with the [shopping list](hardware/procurement/README.md) and [implementation plan](docs/Harmony-2026-implementation-plan.md).

The [original recommendation](docs/Harmony-2026-reassessment.md) explains the Tangara-based approach. The [printing and assembly guide](enclosure/harmony-r1/README.md) contains the current digital fit prototype. Battery sourcing is unresolved and may require a rear-shell/cage revision.

[Supplier briefs](hardware/procurement/supplier-briefs.md) are unsent drafts. No parts ordered or fabrication approved.
