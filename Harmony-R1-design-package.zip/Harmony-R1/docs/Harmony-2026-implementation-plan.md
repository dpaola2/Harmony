# Harmony implementation plan for review

September 13, 2026. HARMONY-9. This is a proposed implementation sequence; supplier orders, firmware changes, and physical assembly have not started.

Build one carryable Harmony using assembled Tangara electronics, the capacitive ring, USB-C, Bluetooth headphones, removable storage, and a printed case. Keep the upstream electronics and playback firmware intact through the first acceptance test. Customize the interface after playback and power work. The [shopping list](../hardware/procurement/README.md) includes sources, quantities, prices, and unresolved items.

## Decisions in this review

| Decision | Proposed default | Effect |
| --- | --- | --- |
| Hardware foundation | Tangara reference electronics with factory assembly | Avoids hand-assembling the dense mainboard; retains wired output as a useful diagnostic fallback. |
| Prototype quantity | Quote 1, 2, and 5 complete board sets; prefer 2 | One working player and one electronics spare. Do not accept a five-set order without seeing the total cost. |
| Display | Retain the 1.8-inch 160 × 128 panel | Lowest integration effort. A higher-resolution screen would be a separate faceplate and enclosure revision. |
| Battery | First quote LP574459 with PCM, NTC, and matching PHR-3 harness | Finished pack fit and small-order availability must be established. Revise the cage/rear shell to the chosen pack. |
| Runtime | Provisional 20 hours of Bluetooth playback | An acceptance target, not an established capability. A 2,000 mAh pack implies an 80 mA average-current planning limit at 80% usable capacity. |
| Budget | Reserve $600–900, excluding a new tool bench | Assistant's allowance, not a quote. Review the landed board and battery costs before purchase. |

The latest user request authorizes sourcing and a plan for review. It does not settle these choices or authorize supplier messages or purchases. The concrete supplier briefs are prepared locally so the next review can cover their actual scope.

## Implementation sequence

| Stage | Work and owner | Evidence required before proceeding | Estimated hands-on effort |
| --- | --- | --- | --- |
| 1. Freeze the electrical and mechanical interfaces | Codex reconciles the exact mainboard/faceplate revisions, display drawing, battery connector/NTC, and case source. Dave supplies existing tool inventory and target headphones when execution starts. | One source manifest, resolved display dimensions, battery pack drawing or an explicit pending item, and a list of board substitutions requiring review. | 3–6 hours |
| 2. Obtain comparable quotes | After authorization, submit the [prepared briefs](../hardware/procurement/supplier-briefs.md) for PCBAs and battery samples. Ask assembler to procure and mount display/motor and program both processors. | Itemized quotes, actual assembly quantities, stocked component allocation, substitutions, test scope, freight/tax, and delivery estimates. | 1–3 hours, plus supplier response time |
| 3. Prove the firmware build before fabrication release | Codex checks out pinned ESP32 and SAMD sources with submodules, builds the unmodified baseline, and records binaries, hashes, toolchains, bootloader, flash layout, and recovery procedure. | Reproducible ESP32 and SAMD builds and a compatible version pair. Initial SAMD programming method agreed with assembler. | 4–8 hours |
| 4. Release the reviewed hardware order | Codex prepares the reconciled BOM, DNP list, Gerbers/drills, placement files, assembly notes, ERC/DRC review, and programming/test instructions. Dave reviews actual purchase total. | No unexplained ERC/DRC errors; every populated item has an orderable MPN; assembler confirms orientation, stack-up, and approved substitutions. Actual order approval is separate from this draft plan. | 3–6 hours |
| 5. Fit prints and software preparation while boards are made | Dave prints the seam coupons and a wheel cover. Codex adjusts local clearances from measurements, prepares a small tagged music library, and adds prospective acceptance logging. Final rear shell waits for the selected battery dimensions. | Seam closes by hand, screw heads seat, button/switch fits are measurable, and the display/lens/battery stack is documented. No whole-model scaling. | 2–4 hours; roughly 20 minutes for coupons |
| 6. Electrical bring-up on the bench | Dave or the assembler inspects boards and verifies power rails/current before full assembly. Load baseline firmware, test SD/display/controls/haptics, then wired and Bluetooth audio. Codex diagnoses logs and changes only the failed subsystem. | One hour of continuous playback, functional controls, clean reset/reconnect, functioning charge path and temperature sensing. Keep a record of board revision and firmware hashes. | 4–8 hours |
| 7. Enclose and test as a pocket player | Revise rear shell/cage to the actual pack, re-run geometry/slicer checks, then Dave prints and assembles. Verify wheel calibration through the real cover, button travel, ports, and radio reception. | Full case closes without compressing battery or LCD; no false touches; walk test and charge tests pass. Record final case revision and filament. | 3–6 hours; about 2½ hours per current full-case print |
| 8. Implement Harmony's interface and qualify the build | Codex makes the theme/navigation changes against the proven baseline, builds release images, and runs regression checks. Dave performs the final use and runtime tests. | Acceptance table below completed with measurements, reproducible release package, and assembly/restore instructions. | 6–12 hours, plus two runtime cycles |

These are planning estimates, totaling **26–53 hands-on hours**, distributed between software work, supplier coordination, and physical assembly. Procurement duration is unknown until quotes arrive. Several weeks is a reasonable scheduling allowance, not a promised delivery date. A PCB respin or unavailable battery may add another procurement cycle.

Stages 3 and the small fit prints can proceed while quotes are pending. Fabrication waits for the electrical review and known programming path. Final rear-shell printing waits for the finished battery dimensions. Keep one electronics set unchanged if two are purchased; it provides a useful comparison when debugging Harmony changes.

## Firmware work

Preserve the current Python simulator as a reference for navigation behavior. Add the actual device firmware as a separately pinned upstream fork or submodule after this plan is accepted. Do not claim the Python audio stubs implement the native playback path. Update project conventions and the old roadmap to distinguish the simulator from the new device target at that point.

Start from ESP32 firmware commit `c092c5aae83aac241b3756b15d8b9dad9ed2c3fd` and hardware commit `9853b4a1dc8a0e3ea3ec75450522e42df12eaa52`. Select and record a compatible SAMD bootloader/application revision. The inspected ESP32 UI requires SAMD application version 3 or newer for USB storage. Version number alone does not prove the pair works; build and exercise it together.

Follow upstream `BUILDING.md`: initialize recursive submodules, install the repository's ESP-IDF tools, source its environment, and build with `idf.py build`. Use the actual connected macOS serial port when flashing. Follow the SAMD project's own build and SWD instructions rather than assuming ESP32 USB flashing initializes both chips. No firmware build or flash has been performed for this sourcing review. [ESP32 firmware](https://codeberg.org/cool-tech-zone/tangara-fw), [SAMD firmware](https://codeberg.org/cool-tech-zone/tangara-samd-fw).

The first Harmony UI pass contains Library, Now Playing, and Settings. Wheel movement scrolls lists, center touch selects, back returns to the previous screen, and side buttons control volume. Preserve upstream hold, Bluetooth pairing, charging, and low-battery handling. Add the Harmony name, colors, and typography; then implement only navigation differences we can test. Local file playback is the first release. Streaming services, phone notifications, Wi-Fi sync, a new display, and new codecs are outside this implementation proposal.

## Acceptance tests

All criteria below are proposed for review. Run them on the closed device with the final battery, SD card, cover, and firmware. Record failures rather than lowering the goal without a decision.

| Capability | Test and proposed pass condition |
| --- | --- |
| Local music | Index at least 1,000 tagged MP3 tracks. Play a full album while browsing; no reset, skipped track, or audio interruption caused by navigation. Include spaces, accented names, missing artwork, and a corrupt file. |
| Wheel and controls | Slow and fast scrolling in both directions, center selection, back, volume, and hold all behave predictably. No unintended input during a 30-minute pocket test. Repeat while charging. |
| Bluetooth | Pair with Dave's actual headphones, reconnect over ten power cycles, and play during a 30-minute walk in each intended pocket. No audible dropouts in those trials. Test the car receiver separately if driving remains a requirement. |
| USB-C | Charge from USB-A and USB-C sources, with C-to-C cable flipped both ways. Check source current limits and battery charge current against the selected pack rating. Verify charge termination and temperature-sensor fault handling. |
| File transfer | Copy music by SD reader first. If USB storage is enabled, verify safe eject and library refresh; the player must not write the card while the computer owns it. Check copied file hashes. |
| Runtime | Two full-charge-to-controlled-shutdown Bluetooth runs, at least 20 hours each. MP3 source, Wi-Fi off, screen timeout fixed, same headphones and volume. Log disconnections and elapsed time; do not extrapolate from a short USB-current reading. |
| Resume and low battery | Ten normal power cycles preserve intended settings/resume state. Low-battery shutdown leaves the SD filesystem readable and the next boot usable. |
| Mechanical | All screws seat in metal standoffs; case closes without force; cell and lens are uncompressed; buttons return; hold and SD removal work; USB plugs seat fully. Photograph cable routing before closing. |
| Serviceability | Open and close three times without broken fittings or trapped wiring. Battery can be removed using its pull tab. Record required screwdriver and screw positions for the final revision. |

If Bluetooth fails in a pocket, compare open-board and enclosed behavior before changing antennas or the case. If runtime misses 20 hours, measure battery-side consumption in playback, display-on, and idle states; try upstream power settings and screen timeout first. A larger pack is a case revision with a new mass and thickness, not a silent substitution. If the printed touch cover is unreliable, test a dimensionally matched insulating FR4 cover before redesigning the sensor PCB.

## Deliverables from implementation

The finished release should contain a locked electronics BOM, actual purchase receipts/quantities, verified firmware source and binaries, a compatible SAMD image/bootloader record, measured battery/runtime results, final STL/3MF/STEP exports, A1 settings, assembly photos, and recovery instructions. Keep CERN-OHL-S hardware attribution and the firmware's applicable license notices with their sources.

For this review, the completed deliverables are the sourced shopping list, supplier briefs, schematic inspection aid, and this plan. Quotes, fabrication outputs, physical tests, and the finished player remain future work.

## Cross-references

- [Shopping list](../hardware/procurement/README.md)
- [Supplier briefs](../hardware/procurement/supplier-briefs.md)
- [Technical basis](Harmony-2026-technical-basis.md)
- [Current enclosure](../enclosure/harmony-r1/README.md)
- HARMONY-9; HARMONY-8; HARMONY-1
